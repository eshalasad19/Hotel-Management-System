import { useState, useEffect } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:5001/api';

const Housekeeping = () => {
  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  const [tasks, setTasks] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [filterStatus, setFilterStatus] = useState('');
  const [rooms, setRooms] = useState([]);
  const [hkStaff, setHkStaff] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [addForm, setAddForm] = useState({ roomId: '', staffId: '' });
  const [updateStatus, setUpdateStatus] = useState('pending');
  const [error, setError] = useState('');

  useEffect(() => { loadTasks(); }, []);

  useEffect(() => {
    setFiltered(filterStatus ? tasks.filter(t => t.cleaningStatus === filterStatus) : tasks);
  }, [filterStatus, tasks]);

  const loadTasks = async () => {
    try {
      const res = await axios.get(`${API_URL}/housekeeping`, { headers });
      setTasks(res.data);
      setFiltered(res.data);
    } catch (err) { console.error(err); }
  };

  const loadModalData = async () => {
    try {
      const [roomsRes, usersRes] = await Promise.all([
        axios.get(`${API_URL}/rooms`, { headers }),
        axios.get(`${API_URL}/auth/users`, { headers })
      ]);
      setRooms(roomsRes.data);
      setHkStaff(usersRes.data.filter(u => u.role === 'housekeeping'));
    } catch (err) { console.error(err); }
  };

  const stats = {
    total: tasks.length,
    pending: tasks.filter(t => t.cleaningStatus === 'pending').length,
    inProgress: tasks.filter(t => t.cleaningStatus === 'in_progress').length,
    completed: tasks.filter(t => t.cleaningStatus === 'completed').length,
  };

  const statusBadge = (status) => {
    const map = {
      pending:     'bg-warning-subtle text-warning',
      in_progress: 'bg-primary-subtle text-primary',
      completed:   'bg-success-subtle text-success'
    };
    return <span className={`badge ${map[status]}`}>{status.replace('_', ' ')}</span>;
  };

  const handleAdd = async () => {
    setError('');
    if (!addForm.roomId || !addForm.staffId) { setError('Please select room and staff.'); return; }
    try {
      await axios.post(`${API_URL}/housekeeping`, { roomId: addForm.roomId, assignedStaff: addForm.staffId }, { headers });
      setShowAddModal(false);
      setAddForm({ roomId: '', staffId: '' });
      loadTasks();
    } catch (err) { setError(err.response?.data?.message || 'Error assigning task.'); }
  };

  const handleUpdateStatus = async () => {
    try {
      await axios.put(`${API_URL}/housekeeping/${selectedTask._id}`, { cleaningStatus: updateStatus }, { headers });
      setShowUpdateModal(false);
      loadTasks();
    } catch (err) { console.error(err); }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`${API_URL}/housekeeping/${selectedTask._id}`, { headers });
      setShowDeleteModal(false);
      loadTasks();
    } catch (err) { console.error(err); }
  };

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 className="mb-sm-0">Housekeeping Management</h4>
            <button className="btn btn-success" onClick={() => { loadModalData(); setAddForm({ roomId: '', staffId: '' }); setError(''); setShowAddModal(true); }}>
              <i className="ri-add-line me-1"></i> Assign Task
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="row mb-3">
        {[
          { label: 'Total Tasks', value: stats.total, icon: 'bx bx-list-ul', color: 'info' },
          { label: 'Pending', value: stats.pending, icon: 'bx bx-time', color: 'warning' },
          { label: 'In Progress', value: stats.inProgress, icon: 'bx bx-loader', color: 'primary' },
          { label: 'Completed', value: stats.completed, icon: 'bx bx-check-circle', color: 'success' },
        ].map((s, i) => (
          <div className="col-md-3 col-6" key={i}>
            <div className="card card-animate">
              <div className="card-body">
                <div className="d-flex align-items-center">
                  <div className="avatar-sm flex-shrink-0">
                    <span className={`avatar-title bg-${s.color}-subtle rounded fs-3`}>
                      <i className={`${s.icon} text-${s.color}`}></i>
                    </span>
                  </div>
                  <div className="flex-grow-1 ms-3">
                    <p className="text-uppercase fw-medium text-muted mb-1 fs-12">{s.label}</p>
                    <h4 className="mb-0 fw-semibold">{s.value}</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="card">
        <div className="card-header d-flex align-items-center">
          <h5 className="card-title mb-0 flex-grow-1">Cleaning Tasks</h5>
          <select className="form-select form-select-sm w-auto" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="">All Status</option>
            <option value="pending">Pending</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead className="table-light">
                <tr><th>#</th><th>Room</th><th>Assigned Staff</th><th>Status</th><th>Assigned On</th><th>Completed At</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan="7" className="text-center py-4 text-muted">No tasks found.</td></tr>
                ) : filtered.map((t, i) => {
                  const staffName = t.assignedStaff?.name || '—';
                  const initials = staffName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
                  return (
                    <tr key={t._id}>
                      <td>{i + 1}</td>
                      <td><span className="fw-medium">{t.roomId ? `Room ${t.roomId.roomNumber} (${t.roomId.type})` : '—'}</span></td>
                      <td>
                        <div className="d-flex align-items-center gap-2">
                          <div className="avatar-xs">
                            <span className="avatar-title rounded-circle bg-success-subtle text-success" style={{ fontSize: '11px' }}>{initials}</span>
                          </div>
                          {staffName}
                        </div>
                      </td>
                      <td>{statusBadge(t.cleaningStatus)}</td>
                      <td><small className="text-muted">{new Date(t.createdAt).toLocaleDateString('en-PK')}</small></td>
                      <td><small className="text-muted">{t.completedAt ? new Date(t.completedAt).toLocaleDateString('en-PK') : '—'}</small></td>
                      <td>
                        <div className="d-flex gap-1">
                          <button className="btn btn-soft-primary btn-sm" onClick={() => { setSelectedTask(t); setUpdateStatus(t.cleaningStatus); setShowUpdateModal(true); }} title="Update Status">
                            <i className="ri-edit-line"></i>
                          </button>
                          <button className="btn btn-soft-danger btn-sm" onClick={() => { setSelectedTask(t); setShowDeleteModal(true); }} title="Delete">
                            <i className="ri-delete-bin-line"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Assign Cleaning Task</h5>
                <button className="btn-close" onClick={() => setShowAddModal(false)}></button>
              </div>
              <div className="modal-body">
                {error && <div className="alert alert-danger">{error}</div>}
                <div className="row g-3">
                  <div className="col-12">
                    <label className="form-label">Select Room <span className="text-danger">*</span></label>
                    <select className="form-select" value={addForm.roomId} onChange={e => setAddForm({ ...addForm, roomId: e.target.value })}>
                      <option value="">Select Room</option>
                      {rooms.map(r => (
                        <option key={r._id} value={r._id}>Room {r.roomNumber} ({r.type}) — {r.status}</option>
                      ))}
                    </select>
                  </div>
                  <div className="col-12">
                    <label className="form-label">Assign Staff <span className="text-danger">*</span></label>
                    <select className="form-select" value={addForm.staffId} onChange={e => setAddForm({ ...addForm, staffId: e.target.value })}>
                      <option value="">Select Housekeeping Staff</option>
                      {hkStaff.length === 0
                        ? <option disabled>No housekeeping staff found</option>
                        : hkStaff.map(u => <option key={u._id} value={u._id}>{u.name}</option>)
                      }
                    </select>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-light" onClick={() => setShowAddModal(false)}>Cancel</button>
                <button className="btn btn-success" onClick={handleAdd}>Assign Task</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Update Status Modal */}
      {showUpdateModal && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-sm">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Update Task Status</h5>
                <button className="btn-close" onClick={() => setShowUpdateModal(false)}></button>
              </div>
              <div className="modal-body">
                <label className="form-label">Status</label>
                <select className="form-select" value={updateStatus} onChange={e => setUpdateStatus(e.target.value)}>
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
              <div className="modal-footer">
                <button className="btn btn-light" onClick={() => setShowUpdateModal(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={handleUpdateStatus}>Update</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-sm">
            <div className="modal-content">
              <div className="modal-body text-center p-4">
                <div className="avatar-md mx-auto mb-3">
                  <span className="avatar-title bg-danger-subtle rounded-circle fs-1">
                    <i className="ri-delete-bin-line text-danger"></i>
                  </span>
                </div>
                <h5>Delete Task?</h5>
                <p className="text-muted">This action cannot be undone.</p>
                <div className="d-flex gap-2 justify-content-center">
                  <button className="btn btn-light" onClick={() => setShowDeleteModal(false)}>Cancel</button>
                  <button className="btn btn-danger" onClick={handleDelete}>Delete</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Housekeeping;